Hello!

This is Dawson Ren’s Python Newsbot. On the most basic level, it scours a news source's XML sitemap for URLs. These articles, which are written in HTML, are then parsed for their title, author, name, and news source, and saved to .txt files within News. The way I've implemented this last step is pretty janky and requires a lot of human input, so that's another problem.

Because each news source stores its past articles in a different way, you’ll notice that each news source has its own folder in here. Whenever you run the .py script with the news source's name (nbc.py, ajz,py, etc.) , you’ll only be parsing the news for that news source.

The way each news source is stored can be found in the info .txt file.

Here’s the list of news sources:

Reuters -- functional
NBC -- functional
Economist -- functional
AJZ -- functional
NYT -- NOT functional, due to downloading xml sitemaps as compressed .gz (gunzip) files. Haven't figured out how to unzip these files within the program. Outside modules haven't worked (I think).

Limitations

Right now, you can only run these python scripts through the shell (such as the native terminal, or a 3rd party IDE such as Eclipse or IDLE). 

They must be run individually on separate threads. 

Additionally, the retrieval and storage of articles is asynchronous, meaning that the program deals with URLs as if you're in a line, serving each URL individually, rather than having multiple lines, serving them in parallel. Pretty inefficient. 

I'd also like to add more sources (although the bottleneck isn't me, it's many news sources shifting to non-online XML sitemaps)

Plus, I'd like to make a GUI so it's more intuitive to interact with.


